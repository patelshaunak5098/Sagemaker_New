def handler(event, context):

    # Your logic goes here
    message = "Hello, world from GET Lambda Func! update lambda"
    print('Hello, world from GET Lambda Func!')
    
    return {
        'statusCode': 200,
        'body': message
    }
